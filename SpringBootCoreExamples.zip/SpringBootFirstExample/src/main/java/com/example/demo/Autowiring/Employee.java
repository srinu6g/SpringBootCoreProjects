package com.example.demo.Autowiring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;


@Component
public class Employee {
	
	@Qualifier("add2")// on top of @Qualifier have highest priority when compared to @primary ,byName
	@Autowired
	private Address add5;

	public Address getAdd5() {
		return add5;
	}

	public void setAdd5(Address add5) {
		this.add5 = add5;
	}

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
		System.out.println("Address class object injecting at employee class level");
	}

	
			
		
	
	

}
