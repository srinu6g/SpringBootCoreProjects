package com.example.demo;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;

import com.example.demo.Autowiring.Address;
import com.example.demo.Autowiring.Employee;

@SpringBootApplication 

public class SpringBootFirstExampleApplication { 

	public static void main(String[] args) {
		
	ApplicationContext context	=SpringApplication.run(SpringBootFirstExampleApplication.class, args);
		System.out.println("Main boot working statrt");
		
		//System.out.println(context.getBean(Address.class));
		 Employee emp1 = context.getBean(Employee.class);
		// System.out.println(emp1.getAddress());
		 System.out.println(emp1);
		
		 
		 
	}
	
	
	@Bean("add2")
	public Address secondAddress()
	{
		return new Address();
	}
	@Bean("add3")
	public Address thirdAddress()
	{
		return new Address();
	}

}

/* com.example.demo this one act as basepackage for springboot internally 
// when we declare  @SpringBootApplication this annotation it is internally derived from 
@ComponentScan
@Configuration
@EnableAutoConfiguration

@ComponentScan("com.example.demo") this base package

but you java files available in "com.example.Autowiring" this package so springboot container cannot read
your files becoz base packege not matching 

com.example.demo  (valid)
com.example.demo.one (valid)
com.example.demo.one.one(valid)
com.example.demo.*(its valid) becoz base package followed by anything that one good
com.example.Autowiring(not valid)
com.example.Autowiring.demo (not valid)
com.example.demo.Autowiring(valid)



ApplicationContext context	=SpringApplication.run(SpringBootFirstExampleApplication.class, args);

the above line indicates create container object 

*/



