package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;

import com.example.demo.Organization.Comapny;
import com.example.demo.Organization.Organization;

@SpringBootApplication
public class SpringBootCiExampleApplication {

	public static void main(String[] args) {
		
	ConfigurableApplicationContext context=	SpringApplication.run(SpringBootCiExampleApplication.class, args);
		
		System.out.println("*************************************  Organization *************************");
		
		Organization org=context.getBean(Organization.class);
		System.out.println(org);
		System.out.println(org.getNoOfcompanies());
		System.out.println(org.getName());
		
		System.out.println(org.getComapny());
		
		
		
	
	
	}
	
	@Bean("two")
	public Comapny companyTwo()
	{
		return new Comapny();
		
	}
	
	@Bean("three")
	public Comapny companyThree()
	{
		return new Comapny();
		
	}
	

}
