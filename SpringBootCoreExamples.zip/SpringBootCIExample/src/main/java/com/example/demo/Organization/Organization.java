package com.example.demo.Organization;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Organization {
	
	private int noOfcompanies;
	
	private String name;
	
	private Comapny comapny;
	

	/*@Autowired
	public Organization(@Qualifier("two") Comapny comapny)
	{
		this.comapny=comapny;
	}
	
	// until now we are creating three bean objects for Comapny class  that is 1)comapny 2)two 3)third

// we are injecting comapny class bean object into a Organization level
	
	// actually getting ambguity issue but why am not getting any issue
	//becoz of  byname
	
	
	public Organization(int noOfcompanies, String name, Comapny comapny) {
		super();
		this.noOfcompanies = noOfcompanies;
		this.name = name;
		this.comapny = comapny;
	}
// now am taking all parameters int,String,comapany class object also
// internally while creating object definately we can pass values 3 parm values
//  Organization o=new  Organization();     wrong
//  Organization o=new  Organization(102);  wrong
	
//  Organization o=new  Organization(102,"virtusa","bean objects available in container level that is responsbility of IOC");
	
	// bean object pass internally by IOC becoz already three bean object availble 
	
	// HOw to pass int ,String  so we have to use @Value annotation
	
	*/
	@Autowired
	public Organization(@Value("102") int noOfcompanies,@Value("virtusa") String name, Comapny comapny) {
		super();
		this.noOfcompanies = noOfcompanies;
		this.name = name;
		this.comapny = comapny;
	}
	
// again same bean object level getting ambiguity issue then use !Qualifier at constructor paramter level

	
	
	public int getNoOfcompanies() {
		return noOfcompanies;
	}

	public void setNoOfcompanies(int noOfcompanies) {
		this.noOfcompanies = noOfcompanies;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Comapny getComapny() {
		return comapny;
	}

	public void setComapny(Comapny comapny) {
		this.comapny = comapny;
	}
	
	
	
	

}
