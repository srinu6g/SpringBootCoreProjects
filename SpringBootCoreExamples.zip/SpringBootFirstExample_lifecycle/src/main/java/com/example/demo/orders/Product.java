package com.example.demo.orders;

import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;

@Component
public class Product {

	public Product() {
		super();
		// TODO Auto-generated constructor stub
		System.out.println("after constructor created");
	}
	
	// working on Annotations
	
	//we can define your own methods and those methods annotate with 
	// @PostConstruct   for  initilizaing
	//@preDestroy for destory/termination purppose
	
	@PostConstruct
	public void abc()
	{
		System.out.println("this is for inilization purpose");
	}
	@PreDestroy
	public void xyz()
	{
		System.out.println("this is for terminating purpose");
	}
	
	
	

}
