package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.example.demo.orders.Order;

@SpringBootApplication
public class SpringBootFirstExampleLifecycleApplication {

	public static void main(String[] args) throws Exception {
		System.out.println("spring bean stareted");
		 ConfigurableApplicationContext context   =SpringApplication.run(SpringBootFirstExampleLifecycleApplication.class, args);
		 
		Order o= context.getBean(Order.class);
		System.out.println("after creating bean object container will check programmer write any bean life cycle methds");
		o.setOrderrId(101);
		System.out.println(o.getOrderrId());
		o.destroy();
		
		System.out.println("before terminating it will call destroy");
		// if you take bean clases every component/bean class object is inilizes only once
		// if take 100 bean classes => 100 times bean objects created every bean class one time 
	}
	

}
