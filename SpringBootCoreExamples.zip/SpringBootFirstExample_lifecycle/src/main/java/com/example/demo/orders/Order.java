package com.example.demo.orders;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

@Component
public class Order implements InitializingBean,DisposableBean {
	
	private int orderrId;
	private String name;
	public int getOrderrId() {
		return orderrId;
	}
	public void setOrderrId(int orderrId) {
		this.orderrId = orderrId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public void destroy() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("Desroying bean object befoer terminating");
	}
	@Override
	public void afterPropertiesSet() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("Inilizaing bean :Inilization : afterProperties set");
		
	}
	
	
	
}
