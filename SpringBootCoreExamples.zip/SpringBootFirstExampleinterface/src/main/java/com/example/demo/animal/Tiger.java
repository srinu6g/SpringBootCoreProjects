package com.example.demo.animal;

import org.springframework.stereotype.Component;

@Component
public class Tiger implements Animal {

	@Override
	public int getNoOfAnimals() {
		// TODO Auto-generated method stub
		return 15;
	}

	@Override
	public String nameOfAnimal() {
		// TODO Auto-generated method stub
		return "Tiger";
	}

}
