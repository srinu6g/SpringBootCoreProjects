package com.example.demo.animal;

import org.springframework.stereotype.Component;

@Component
public class Lion implements Animal {

	@Override
	public int getNoOfAnimals() {
		// TODO Auto-generated method stub
		return 20;
	}

	@Override
	public String nameOfAnimal() {
		// TODO Auto-generated method stub
		return "Lion";
	}

}
