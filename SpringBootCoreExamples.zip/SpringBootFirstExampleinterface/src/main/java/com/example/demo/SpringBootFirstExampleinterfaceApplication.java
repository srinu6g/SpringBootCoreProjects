package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.example.demo.animal.Lion;
import com.example.demo.animal.Tiger;
import com.example.demo.animal.Zoo;

@SpringBootApplication
public class SpringBootFirstExampleinterfaceApplication {

	public static void main(String[] args) {
		
		ApplicationContext context=SpringApplication.run(SpringBootFirstExampleinterfaceApplication.class, args);
		Lion l1=context.getBean(Lion.class);
		System.out.println(l1);
		
		Tiger t1=context.getBean(Tiger.class);
		System.out.println(t1);
		System.out.println(t1.getNoOfAnimals());
		
		Zoo zoo=context.getBean(Zoo.class);
		System.out.println(zoo);
		System.out.println(zoo.getLion());
		System.out.println(zoo.getLion().getNoOfAnimals());
	
	
		
	}
	
	

}
