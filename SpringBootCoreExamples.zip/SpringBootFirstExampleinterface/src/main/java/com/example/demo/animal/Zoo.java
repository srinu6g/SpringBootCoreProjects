package com.example.demo.animal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Zoo {
	
	@Autowired
	private Lion lion;

	public Lion getLion() {
		return lion;
	}

	public void setLion(Lion lion) {
		this.lion = lion;
	}

	public Zoo() {
		System.out.println("ZOO clas obj");
	}
	

}
