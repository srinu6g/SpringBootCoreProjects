package com.example.demo.animal;

public interface Animal {
	
	
	public int getNoOfAnimals();
	
	public String nameOfAnimal();
	
	
	

}
