package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import com.example.demo.value.DbConnection;
import com.example.demo.value.DbConnectionThree;
import com.example.demo.value.DbConnectionTwo;

@SpringBootApplication
public class SpringBootFirstExampleValueAnnotationApplication {

	public static void main(String[] args) {
	ConfigurableApplicationContext context= SpringApplication.run(SpringBootFirstExampleValueAnnotationApplication.class, args);
	
	DbConnection con=context.getBean(DbConnection.class);
	
	/*System.out.println(con);
	
	System.out.println(con.getUrl());
	System.out.println(con.getUname());
	System.out.println(con.getPwd());
	
	// my component class as "DbConnection" and declared class as component
	// now we are getting values from component class getting as default so we can replace your default values  with hard code/real values 
	// by using @Value annoation */
	// above code is before apply @Value annoation 
	
	System.out.println("*************After using @Value annotation*******************");
	
	System.out.println(con.getUrl());
	System.out.println(con.getUname());
	System.out.println(con.getPwd());
	
	
System.out.println("*************After using @Value annotation at application properties level*******************");
DbConnectionTwo conn2=context.getBean(DbConnectionTwo.class);
	System.out.println(conn2.getUrl());
	System.out.println(conn2.getUname());
	System.out.println(conn2.getPwd());
	
	
	System.out.println("*************After using @Value annotation at application properties level*******************");
	DbConnectionThree conn3=context.getBean(DbConnectionThree.class);
		System.out.println(conn3.getUrl());
		System.out.println(conn3.getUname());
		System.out.println(conn3.getPwd());
		
		//note if you want to change pwd in your appliactio properties level that will reflect DbConnectionTwo,DbConnectionThree classesof which property value you change
		
	
	}

} 

/*
 * @value anotation using at constructor paramter level, field property level and application.proprties we can acces at property level 
 * 
 */
