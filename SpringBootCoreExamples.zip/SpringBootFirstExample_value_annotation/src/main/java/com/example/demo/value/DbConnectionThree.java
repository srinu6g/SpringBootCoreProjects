package com.example.demo.value;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class DbConnectionThree {
	
	
	// hardcode  we are changing any value at property level  
	// but this only one component class so that ther is no problem 
	// but in real time 20 component classes with same properties so that 
	// any one of them property value you want change then 20 component class with that particular property
	// you want change
	
	// inplace of hardcode you want change 20 component classes pwd valu 20 times simply you have to write in 
	// one universal path and use that one easy if you want any changes in future that changes will do in univeraal level
	// that reflect will automatically all property values
	
	// universal path => application.properties this is working am taking DbConnectionTwo class
	
	
	// now my pwd is "srinivas123" but tomorrow i want to change my pwd=>srinivas123 => amma123
	//simple we can change value of pwd is srinivas123 => amma123 this is a hardcode
	
	
	@Value("${db.url}")
	private String url;
	@Value("${db.uname}")
	private String uname;
	@Value("${db.pwd}")
	private String pwd;
	
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	
	
	

}
